Hi, there
This program will help you to protect your privacy files.
And will improve system performance.